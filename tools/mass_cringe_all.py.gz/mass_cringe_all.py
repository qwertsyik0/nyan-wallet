import os, sys, time, json, hmac, hashlib, html, subprocess, urllib.request
from pathlib import Path
from dotenv import load_dotenv

load_dotenv('/home/nyanteam/new_bot/.env')
TOKEN = os.getenv('BOT_TOKEN', '').strip()
OWNER = int(os.getenv('OWNER_TELEGRAM_ID') or '0')
STATE = Path('/home/nyanteam/new_bot/mass_cringe_sent.json')
API = 'https://nyan-wallet-153-76-175-145.sslip.io/api/internal/broadcast/recipients'
if not TOKEN:
    sys.exit('ОШИБКА: BOT_TOKEN отсутствует')
if not OWNER:
    sys.exit('ОШИБКА: OWNER_TELEGRAM_ID отсутствует')

def telegram(method, data):
    p = subprocess.run([
        'curl', '-6', '-sS', '--connect-timeout', '8', '--max-time', '18',
        '-H', 'Content-Type: application/json', '--data-binary', '@-',
        f'https://api.telegram.org/bot{TOKEN}/{method}'
    ], input=json.dumps(data, ensure_ascii=False).encode(),
       capture_output=True, timeout=22)
    if p.returncode:
        raise RuntimeError(f'Telegram: {p.stderr.decode(errors="replace").strip()}')
    return json.loads(p.stdout)

def recipients():
    result, after = [], 0
    while True:
        body = json.dumps({'owner_telegram_id': OWNER, 'audience': 'all',
                           'after_telegram_id': after, 'limit': 500},
                          separators=(',', ':')).encode()
        timestamp = str(int(time.time()))
        signature = hmac.new(TOKEN.encode(), timestamp.encode() + b'\n' + body,
                             hashlib.sha256).hexdigest()
        req = urllib.request.Request(API, data=body, method='POST', headers={
            'Content-Type': 'application/json', 'X-Nyan-Timestamp': timestamp,
            'X-Nyan-Signature': signature})
        with urllib.request.urlopen(req, timeout=20) as response:
            page = json.load(response)
        if not page.get('ok'):
            raise RuntimeError('API не подтвердил получателей')
        result.extend(int(x) for x in page['recipients'])
        if not page['has_more']:
            return list(dict.fromkeys(result))
        new_after = int(page['next_after_telegram_id'])
        if new_after <= after:
            raise RuntimeError('Ошибка пагинации')
        after = new_after

def save(sent):
    temp = STATE.with_suffix('.tmp')
    temp.write_text(json.dumps(sorted(sent)), encoding='utf-8')
    os.replace(temp, STATE)

if not telegram('getMe', {}).get('ok'):
    sys.exit('ОШИБКА: Telegram отверг токен')
print('Telegram IPv6: OK', flush=True)
test_only = '--test' in sys.argv
ids = [OWNER] if test_only else recipients()
sent = set() if test_only else (set(json.loads(STATE.read_text())) if STATE.exists() else set())
print(f'Всего пользователей: {len(ids)}; уже отправлено: {len(sent.intersection(ids))}')
if '--send' not in sys.argv and not test_only:
    sys.exit('ПРОВЕРКА: рассылка не отправлялась. Для проверки письма добавь --test; для запуска --send')

ok = failed = 0
for number, uid in enumerate(ids, 1):
    if uid in sent:
        continue
    try:
        info = telegram('getChat', {'chat_id': uid})
        user = info.get('result', {}) if info.get('ok') else {}
        name = ('@' + user['username']) if user.get('username') else (
            ' '.join(filter(None, [user.get('first_name'), user.get('last_name')])) or 'друг')
        link = f'<a href="tg://user?id={uid}">{html.escape(name)}</a>'
        message = (f'🚨 Внимание, многоуважаемый {link}!\n\n'
                   'Нянская система зафиксировала критический уровень кринжа! '
                   'Котики требуют срочно погладить подушку и выпить чай. 🐾\n\n'
                   'Это шуточное сообщение. Ваш кошелёк не заблокирован, '
                   'лапкоины не списаны.\n\nС любовью, Nyan Wallet.')
        response = telegram('sendMessage', {'chat_id': uid, 'text': message,
                                            'parse_mode': 'HTML'})
        if response.get('ok'):
            if not test_only:
                sent.add(uid)
                save(sent)
            ok += 1
            print(f'[{number}/{len(ids)}] OK: {uid}', flush=True)
        else:
            failed += 1
            print(f'[{number}/{len(ids)}] ПРОПУСК: {uid}: {response.get("description")}', flush=True)
    except Exception as exc:
        failed += 1
        print(f'[{number}/{len(ids)}] ОШИБКА: {uid}: {exc}', flush=True)
    time.sleep(0.5)
print(f'ИТОГО: отправлено {ok}, ошибок {failed}, ранее отправлено {len(sent)-ok}')

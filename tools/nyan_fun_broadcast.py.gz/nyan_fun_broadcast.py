#!/usr/bin/env python3
"""Owner opt-in clearly identified playful Nyan Wallet broadcast; no database mutations."""
import hashlib
import hmac
import html
import json
import os
import sys
import time
from pathlib import Path

import httpx
from dotenv import load_dotenv

ROOT = Path('/home/nyanteam/new_bot')
load_dotenv(ROOT / '.env')
TOKEN = os.getenv('BOT_TOKEN', '').strip()
OWNER = int(os.getenv('OWNER_TELEGRAM_ID', '6289461565'))
API = 'https://nyan-wallet-153-76-175-145.sslip.io'
STATE = ROOT / 'nyan_parody_sent_ids.txt'


def api_recipients():
    ids = []
    after = 0
    with httpx.Client(timeout=25, trust_env=True) as http:
        while True:
            payload = {'owner_telegram_id': OWNER, 'audience': 'all', 'after_telegram_id': after, 'limit': 500}
            body = json.dumps(payload, separators=(',', ':')).encode()
            stamp = str(int(time.time()))
            signature = hmac.new(TOKEN.encode(), stamp.encode()+b'\n'+body, hashlib.sha256).hexdigest()
            resp = http.post(API+'/api/internal/broadcast/recipients', content=body, headers={
                'Content-Type': 'application/json', 'X-Nyan-Timestamp': stamp, 'X-Nyan-Signature': signature
            })
            if resp.status_code != 200:
                raise RuntimeError(f'API получателей: HTTP {resp.status_code}, {resp.text[:250]}')
            data = resp.json()
            page = data['recipients']
            ids.extend(page)
            if not data['has_more']:
                break
            next_id = data['next_after_telegram_id']
            if not page or next_id <= after:
                raise RuntimeError('Ошибка пагинации списка пользователей')
            after = next_id
    return list(dict.fromkeys(ids))


def telegram_client():
    for name, opts in (
        ('с системными настройками сети', {'trust_env': True}),
        ('напрямую через IPv6', {'transport': httpx.HTTPTransport(local_address='::'), 'trust_env': False}),
    ):
        client = httpx.Client(timeout=httpx.Timeout(20, connect=7), **opts)
        try:
            rsp = client.get(f'https://api.telegram.org/bot{TOKEN}/getMe')
            data = rsp.json()
            if data.get('ok'):
                print('Telegram API работает', name, '| бот @'+data['result']['username'])
                return client
            print('Telegram API:', data.get('description', 'ошибка'))
        except Exception as exc:
            print('Telegram API недоступен', name, type(exc).__name__)
        client.close()
    raise RuntimeError('Telegram API недоступен с обоих маршрутов')


def telegram_post(client, method, payload):
    url = f'https://api.telegram.org/bot{TOKEN}/{method}'
    for attempt in range(4):
        try:
            resp = client.post(url, json=payload)
            data = resp.json()
            if data.get('ok'):
                return data
            if resp.status_code == 429:
                time.sleep(min(30, max(1, int(data.get('parameters', {}).get('retry_after', 3)))))
                continue
            return data
        except (httpx.TimeoutException, httpx.TransportError):
            if attempt == 3:
                raise
            time.sleep(attempt+1)
    return {'ok': False, 'description': 'лимит попыток'}


def main():
    if not TOKEN:
        raise RuntimeError('BOT_TOKEN не найден в .env')
    is_send = len(sys.argv) == 2 and sys.argv[1] == '--send'
    if len(sys.argv) > 1 and not is_send:
        raise RuntimeError('Запуск: без аргументов — проверка, --send — отправка')
    client = telegram_client()
    with client:
        ids = api_recipients()
        done = set(STATE.read_text().split()) if STATE.exists() else set()
        pending = [uid for uid in ids if str(uid) not in done]
        print(f'Пользователей: {len(ids)}; уже отправлено: {len(done & set(map(str, ids)))}; ожидают: {len(pending)}')
        print('Режим:', 'ОТПРАВКА' if is_send else 'ПРОВЕРКА — без сообщений')
        if not is_send:
            return
        ok = fail = 0
        for idx, uid in enumerate(pending, 1):
            display = 'друг'
            try:
                r = telegram_post(client, 'getChat', {'chat_id': uid})
                if r.get('ok'):
                    chat = r['result']
                    name = ' '.join((chat.get('first_name') or '', chat.get('last_name') or '')).strip()
                    display = name or ('@'+chat['username'] if chat.get('username') else 'друг')
                person = f'<a href="tg://user?id={uid}">{html.escape(display)}</a>'
                message = (
                    f'🎃 ВНИМАНИЕ, ШУТОЧНАЯ РАССЫЛКА!\n\n'
                    f'Многоуважаемый {person}, система Nyan Wallet обнаружила у вас подозрительно высокий уровень няшности. '
                    'Вас срочно вызывают на внеплановое заседание Совета Лапок! 🐾\n\n'
                    'Это шутка: ваш кошелёк не заблокирован, баланс не списан и никаких обвинений нет.\n\n'
                    'С уважением, команда Nyan Wallet.'
                )
                sent = telegram_post(client, 'sendMessage', {
                    'chat_id': uid, 'text': message, 'parse_mode': 'HTML',
                    'disable_web_page_preview': True,
                })
                if sent.get('ok'):
                    with STATE.open('a') as log:
                        log.write(str(uid)+'\n')
                        log.flush()
                        os.fsync(log.fileno())
                    ok += 1
                else:
                    fail += 1
                    print(f'[{idx}/{len(pending)}] {uid}: {sent.get("description", "ошибка")}')
            except Exception as exc:
                fail += 1
                print(f'[{idx}/{len(pending)}] {uid}: {type(exc).__name__}: {exc}')
            time.sleep(0.5)
        print(f'ИТОГ: отправлено {ok}, не доставлено {fail}; успешно отправленные записаны в {STATE}')

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('ОШИБКА:', exc)
        sys.exit(1)

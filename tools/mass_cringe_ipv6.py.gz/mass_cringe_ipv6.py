#!/usr/bin/env python3
"""Opt-in Nyan Wallet joke mailing over Telegram IPv6.

Usage:
  python mass_cringe_ipv6.py               # preview only
  python mass_cringe_ipv6.py --test 12345  # send one test message
  python mass_cringe_ipv6.py --send        # send to CSV recipients

CSV: telegram_id,username,first_name,last_name
"""
from __future__ import annotations

import argparse
import csv
import html
import os
import sys
import time
from pathlib import Path

import httpx
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")

parser = argparse.ArgumentParser(description="Шуточная рассылка Nyan Wallet через IPv6")
mode = parser.add_mutually_exclusive_group()
mode.add_argument("--send", action="store_true", help="Отправить по списку CSV")
mode.add_argument("--test", type=int, metavar="TELEGRAM_ID", help="Отправить одному пользователю")
args = parser.parse_args()

csv_path = ROOT / "nyan_recipients.csv"
sent_path = ROOT / "mass_cringe_sent_ids.txt"
token = (os.getenv("BOT_TOKEN") or "").strip()


def recipients_from_csv() -> dict[int, dict[str, str]]:
    if not csv_path.is_file():
        if args.test:
            print("CSV пока отсутствует: тестовое сообщение без персональных данных CSV")
            return {}
        raise SystemExit(f"ОШИБКА: нет {csv_path}. Сначала перенесите CSV с FirstVDS")
    with csv_path.open("r", encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        if "telegram_id" not in (reader.fieldnames or []):
            raise SystemExit("ОШИБКА: в CSV нужна колонка telegram_id")
        people: dict[int, dict[str, str]] = {}
        for row in reader:
            uid_text = (row.get("telegram_id") or "").strip()
            if uid_text.isdecimal() and int(uid_text) > 0:
                people[int(uid_text)] = row
    return people


def already_sent() -> set[int]:
    if not sent_path.is_file():
        return set()
    return {int(s) for s in sent_path.read_text(encoding="utf-8").splitlines() if s.isdecimal()}


def save_success(uid: int) -> None:
    # Append only after confirmed Telegram API ok=true; safe on reruns.
    fd = os.open(sent_path, os.O_CREAT | os.O_APPEND | os.O_WRONLY, 0o600)
    with os.fdopen(fd, "a", encoding="utf-8") as file:
        file.write(f"{uid}\n")
        file.flush()
        os.fsync(file.fileno())


def compose(uid: int, user: dict[str, str]) -> str:
    username = (user.get("username") or "").strip().lstrip("@")
    first = (user.get("first_name") or "").strip()
    last = (user.get("last_name") or "").strip()
    name = f"@{username}" if username else f"{first} {last}".strip() or "друг"
    profile = f'<a href="tg://user?id={uid}">{html.escape(name)}</a>'
    return (
        "🚨‼️ НЯНСКАЯ ТРЕВОГА ‼️🚨\n\n"
        f"Многоуважаемый {profile}! 🌸🎀\n\n"
        "Наша супер-пупер-нейросеть 🤖🐾 обнаружила критическое "
        "превышение уровня котячьего величия! 💥🤡\n\n"
        "Ваша карма улетела в созвездие Бездны, а гольфы "
        "официально признаны объектом нянского внимания. 🧦✨\n\n"
        "Приговор: немедленно погладить кота и продолжать жить "
        "свою лучшую жизнь. 🐈💖\n\n"
        "Это шуточная рассылка. Ваш кошелёк работает, баланс не изменён.\n\n"
        "С уважением, администрация Nyan Wallet 🐾"
    )


def send_one(client: httpx.Client, api: str, uid: int, user: dict[str, str]) -> tuple[bool, str]:
    payload = {
        "chat_id": uid,
        "text": compose(uid, user),
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    for _ in range(4):
        try:
            response = client.post(api + "sendMessage", json=payload)
            data = response.json()
        except (httpx.RequestError, ValueError) as error:
            # Telegram might have accepted the request before a timeout.
            # Never retry an uncertain delivery automatically.
            return False, f"Доставка не подтверждена ({type(error).__name__}); проверьте вручную"
        if data.get("ok") is True:
            return True, "Отправлено"
        if data.get("error_code") == 429:
            seconds = int((data.get("parameters") or {}).get("retry_after", 1)) + 1
            if seconds > 120:
                return False, f"Лимит Telegram, ожидание {seconds} секунд"
            print(f"Лимит Telegram: ожидание {seconds} секунд")
            time.sleep(seconds)
            continue
        return False, str(data.get("description", f"HTTP {response.status_code}"))
    return False, "Повторный лимит Telegram"


people = recipients_from_csv()
completed = already_sent()
pending = [uid for uid in people if uid not in completed]
print(f"Всего получателей: {len(people)}; отправлено ранее: {len(people.keys() & completed)}; осталось: {len(pending)}")

if not args.send and args.test is None:
    print("ПРОВЕРКА: рассылка не запущена. Для теста: --test TELEGRAM_ID, для отправки: --send")
    sys.exit(0)

if not token:
    raise SystemExit("ОШИБКА: отсутствует BOT_TOKEN в .env (не публикуйте его)")

api = f"https://api.telegram.org/bot{token}/"
with httpx.Client(transport=httpx.HTTPTransport(local_address="::"), trust_env=False, timeout=20.0) as client:
    try:
        response = client.get(api + "getMe")
        response.raise_for_status()
        bot = response.json()
        if bot.get("ok") is not True:
            raise ValueError("getMe вернул ошибку")
    except (httpx.RequestError, httpx.HTTPStatusError, ValueError) as error:
        raise SystemExit(f"ОШИБКА: Telegram API через IPv6 недоступен ({type(error).__name__})") from error
    print("Бот: @" + bot["result"].get("username", "unknown"))

    if args.test is not None:
        if args.test <= 0:
            raise SystemExit("ОШИБКА: неверный Telegram ID для теста")
        if args.test in completed:
            print("Этому пользователю сообщение уже отправлялось, тест отменён")
            sys.exit(0)
        ok, status = send_one(client, api, args.test, people.get(args.test, {}))
        print("ТЕСТ:", "УСПЕШНО" if ok else "ОШИБКА", status)
        if ok and args.test in people:
            save_success(args.test)
        sys.exit(0 if ok else 1)

    if not pending:
        print("Рассылка уже завершена, повторных сообщений нет")
        sys.exit(0)

    success = failures = 0
    for index, uid in enumerate(pending, 1):
        ok, status = send_one(client, api, uid, people[uid])
        if ok:
            save_success(uid)
            success += 1
        else:
            failures += 1
        print(f"[{index}/{len(pending)}] ID {uid}: {status}", flush=True)
        time.sleep(0.6)
    print(f"ИТОГ: подтверждено {success}; ошибки или неизвестная доставка {failures}")
    if failures:
        print("Не повторяйте неизвестные доставки без проверки, чтобы избежать дублей")

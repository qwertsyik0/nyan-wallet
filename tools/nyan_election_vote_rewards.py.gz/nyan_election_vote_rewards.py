#!/usr/bin/env python3
"""One-time, idempotent voter bonus and two separate Telegram DMs for Nyan Elections.

Run as root ON THE FIRSTVDS SERVER (the one holding the PostgreSQL database):
  python3 nyan_election_vote_rewards.py --check
  python3 nyan_election_vote_rewards.py --apply

Credits every voter in the latest season exactly once (200 lapcoins), and records
separate delivery status for the grant notification and the thank-you letter.
Reruns deliver outstanding messages and can credit newly-arrived voters without
rewarding the same Telegram account twice in the same season.
"""
from __future__ import annotations

import argparse
import html
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

DATABASE = "nyan_wallet_db"
PROJECT = Path("/opt/nyan-wallet")
REWARD = 200
REASON = "голосование в выборах"
LEDGER = "election_vote_reward_delivery"
EXPECTED_BOT = "nyancash_bot"


def sql_query(sql: str) -> str:
    cmd = [
        "runuser", "-u", "postgres", "--", "psql", "-X", "-q", "-t", "-A",
        "-v", "ON_ERROR_STOP=1", "-d", DATABASE,
    ]
    result = subprocess.run(cmd, input=sql, text=True, capture_output=True, check=False)
    if result.returncode:
        raise RuntimeError("PostgreSQL: " + (result.stderr or result.stdout).strip()[-1800:])
    lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    return lines[-1] if lines else ""


def sql_json(sql: str):
    raw = sql_query(sql)
    if not raw:
        raise RuntimeError("PostgreSQL не вернул результат")
    return json.loads(raw)


def latest_season() -> int:
    value = sql_query("SELECT COALESCE(MAX(id), 0) FROM election_seasons;")
    season_id = int(value)
    if season_id <= 0:
        raise RuntimeError("В базе отсутствует сезон Nyan Elections")
    return season_id


def operation_type(season_id: int) -> str:
    operation = f"election_vote_reward_s{season_id}"
    if len(operation) > 50:
        raise RuntimeError("Номер сезона слишком велик")
    return operation


def get_preview(season_id: int) -> dict:
    op = operation_type(season_id)
    # Values interpolated here are a checked integer and our own fixed string.
    return sql_json(f"""
        SELECT row_to_json(t)::text FROM (
          SELECT
            {season_id}::integer AS season_id,
            (SELECT COUNT(*) FROM election_votes WHERE season_id = {season_id}) AS voters,
            (SELECT COUNT(*) FROM election_votes v WHERE v.season_id = {season_id}
               AND EXISTS (SELECT 1 FROM transactions t
                 WHERE t.telegram_id = v.telegram_id AND t.operation_type = '{op}'))
                AS previously_rewarded
        ) t;
    """)


def read_bot_token() -> str:
    token = os.getenv("BOT_TOKEN", "").strip()
    if token:
        return token
    env_file = PROJECT / ".env"
    if not env_file.is_file():
        raise RuntimeError("Не найден BOT_TOKEN: файл /opt/nyan-wallet/.env отсутствует")
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line.startswith("export "):
            line = line[7:].strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, _, value = line.partition("=")
        if name.strip() != "BOT_TOKEN":
            continue
        value = value.strip()
        if len(value) > 1 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        if value:
            return value
    raise RuntimeError("BOT_TOKEN не найден в /opt/nyan-wallet/.env")


def telegram_request(token: str, method: str, fields: dict | None = None) -> dict:
    url = f"https://api.telegram.org/bot{token}/{method}"
    payload = urllib.parse.urlencode(fields).encode("utf-8") if fields else None
    request = urllib.request.Request(url, data=payload, method="POST" if fields else "GET")
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            data = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        try:
            error = json.loads(exc.read().decode("utf-8"))
        except (ValueError, UnicodeError):
            raise RuntimeError(f"Telegram API HTTP {exc.code}") from None
        delay = error.get("parameters", {}).get("retry_after")
        if delay:
            raise RateLimited(int(delay)) from None
        raise RuntimeError(str(error.get("description", f"HTTP {exc.code}"))) from None
    except urllib.error.URLError as exc:
        raise RuntimeError("Сетевая ошибка Telegram API: " + str(exc.reason)) from None
    if not data.get("ok"):
        raise RuntimeError(str(data.get("description", "Telegram API вернул ok=false")))
    return data.get("result", {})


class RateLimited(Exception):
    def __init__(self, seconds: int):
        self.seconds = seconds
        super().__init__(f"Telegram ограничил частоту: {seconds} с")


def send_message(token: str, telegram_id: int, message: str) -> None:
    fields = {
        "chat_id": str(telegram_id),
        "text": message,
        "parse_mode": "HTML",
        "disable_web_page_preview": "true",
    }
    for attempt in range(3):
        try:
            telegram_request(token, "sendMessage", fields)
            return
        except RateLimited as exc:
            if attempt == 2:
                raise RuntimeError(str(exc)) from None
            time.sleep(min(max(exc.seconds, 1), 35))


def apply_credits(season_id: int) -> dict:
    op = operation_type(season_id)
    # Single ACID transaction. The advisory lock serializes concurrent runs.
    # The temp set is computed AFTER the lock, preventing duplicate credits.
    statement = f"""
BEGIN;
SELECT pg_advisory_xact_lock(39206174, {season_id});
DO $$ BEGIN
  IF (SELECT MAX(id) FROM election_seasons) <> {season_id} THEN
    RAISE EXCEPTION 'Сезон изменился во время выполнения; начисления отменены';
  END IF;
END $$;
CREATE TABLE IF NOT EXISTS {LEDGER} (
  season_id integer NOT NULL,
  telegram_id bigint NOT NULL,
  rewarded_at timestamptz NOT NULL DEFAULT NOW(),
  reward_message_sent_at timestamptz NULL,
  thanks_message_sent_at timestamptz NULL,
  PRIMARY KEY (season_id, telegram_id)
);
CREATE TEMP TABLE _nyan_new_election_rewards ON COMMIT DROP AS
SELECT v.telegram_id
FROM election_votes v
JOIN users u ON u.telegram_id = v.telegram_id
WHERE v.season_id = {season_id}
  AND NOT EXISTS (
    SELECT 1 FROM transactions t
    WHERE t.telegram_id = v.telegram_id AND t.operation_type = '{op}'
  )
  AND NOT EXISTS (
    SELECT 1 FROM {LEDGER} d
    WHERE d.season_id = {season_id} AND d.telegram_id = v.telegram_id
  );
UPDATE users u
SET balance = u.balance + {REWARD}
FROM _nyan_new_election_rewards n
WHERE u.telegram_id = n.telegram_id;
INSERT INTO transactions (telegram_id, amount, operation_type, description, created_at)
SELECT telegram_id, {REWARD}, '{op}', '{REASON}', NOW()
FROM _nyan_new_election_rewards;
INSERT INTO wallet_notifications (telegram_id, kind, title, body, is_read, created_at)
SELECT telegram_id, 'election_vote_reward', 'Начислено +200 🐾',
       'Причина: {REASON}', FALSE, NOW()
FROM _nyan_new_election_rewards;
INSERT INTO admin_audit (action, target_telegram_id, details, created_at)
SELECT 'election_vote_reward', telegram_id,
       '+200 🐾 · {REASON} · сезон #{season_id}', NOW()
FROM _nyan_new_election_rewards;
INSERT INTO {LEDGER} (season_id, telegram_id)
SELECT v.season_id, v.telegram_id
FROM election_votes v
WHERE v.season_id = {season_id}
  AND EXISTS (
    SELECT 1 FROM transactions t
    WHERE t.telegram_id = v.telegram_id AND t.operation_type = '{op}'
  )
ON CONFLICT (season_id, telegram_id) DO NOTHING;
SELECT row_to_json(result)::text FROM (
  SELECT
    (SELECT COUNT(*) FROM _nyan_new_election_rewards) AS credited_now,
    (SELECT COUNT(*) FROM {LEDGER} WHERE season_id = {season_id}) AS reward_receipts,
    (SELECT COUNT(*) FROM election_votes WHERE season_id = {season_id}) AS voters
) result;
COMMIT;
"""
    # psql's last *nonempty* line is the JSON row (COMMIT is quiet with -q).
    return sql_json(statement)


def pending_deliveries(season_id: int) -> list[dict]:
    # Includes all credited voters, including earlier executions, not future voters.
    return sql_json(f"""
      SELECT COALESCE(json_agg(row_to_json(r) ORDER BY r.telegram_id), '[]'::json)::text
      FROM (
        SELECT d.telegram_id, u.username, u.first_name, u.last_name,
               (d.reward_message_sent_at IS NOT NULL) AS reward_sent,
               (d.thanks_message_sent_at IS NOT NULL) AS thanks_sent
        FROM {LEDGER} d JOIN users u ON u.telegram_id = d.telegram_id
        WHERE d.season_id = {season_id}
        ORDER BY d.telegram_id
      ) r;
    """)


def mark_delivered(season_id: int, telegram_id: int, column: str) -> None:
    if column not in {"reward_message_sent_at", "thanks_message_sent_at"}:
        raise ValueError("Недопустимая колонка")
    assert season_id > 0 and telegram_id > 0
    sql_query(f"""
      UPDATE {LEDGER} SET {column} = NOW()
      WHERE season_id = {season_id} AND telegram_id = {telegram_id}
        AND {column} IS NULL;
      SELECT 'ok';
    """)


def thank_you(telegram_id: int, first_name: str | None, last_name: str | None,
              username: str | None) -> str:
    real_name = " ".join((first_name or "").split() + (last_name or "").split()).strip()
    name = real_name or (("@" + username.strip().lstrip("@")) if username else "участник")
    linked_name = f'<a href="tg://user?id={telegram_id}">{html.escape(name)}</a>'
    return (
        f"Многоуважаемый {linked_name}!\n\n"
        "Благодарим вас за участие в жизни Nyan Wallet и в выборах Nyan Elections. "
        "Нам приятно, что вы находите время поддерживать проект и участвовать в его развитии.\n\n"
        "Спасибо за ваше участие и доверие.\n\n"
        "С уважением,\nкоманда Nyan Wallet 🐾"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--check", action="store_true", help="Проверка без каких-либо изменений")
    modes.add_argument("--apply", action="store_true", help="Начислить +200 и отправить 2 сообщения каждому")
    args = parser.parse_args()
    if not (PROJECT / "server" / "elections_voting.py").is_file():
        raise RuntimeError("Неправильный сервер: не найден /opt/nyan-wallet/server/elections_voting.py")
    if os.geteuid() != 0:
        raise RuntimeError("Запустите скрипт под root на FirstVDS")

    season_id = latest_season()
    preview = get_preview(season_id)
    total = int(preview["voters"])
    old = int(preview["previously_rewarded"])
    print(f"Nyan Elections · сезон #{season_id}")
    print(f"Проголосовали: {total} · уже начислено этим скриптом: {old}")
    print(f"Осталось начислить: {total - old} × {REWARD} 🐾 = {(total - old) * REWARD} 🐾")
    if args.check:
        print("ПРОВЕРКА: данные и балансы не изменялись; сообщения не отправлялись.")
        return 0
    if not total:
        print("Проголосовавших нет. Действие отменено.")
        return 0

    token = read_bot_token()
    me = telegram_request(token, "getMe")
    username = str(me.get("username", ""))
    if username.lower() != EXPECTED_BOT:
        raise RuntimeError(f"В конфигурации другой бот: @{username}; ожидался @{EXPECTED_BOT}")
    print("Отправитель личных сообщений: @" + username)

    result = apply_credits(season_id)
    print(f"Начислено сейчас: {result['credited_now']} × {REWARD} 🐾")
    print(f"Всего получателей награды: {result['reward_receipts']}")
    print("Балансы и операции сохранены в PostgreSQL. Отправляю личные сообщения...")

    entries = pending_deliveries(season_id)
    message_ok = {"reward": 0, "thanks": 0}
    failed = []
    for entry in entries:
        uid = int(entry["telegram_id"])
        name = ("@" + entry["username"]) if entry.get("username") else f"ID {uid}"
        if not entry["reward_sent"]:
            try:
                send_message(token, uid, "+200 🐾 начислено на ваш Nyan Wallet.\nПричина: голосование в выборах.")
                mark_delivered(season_id, uid, "reward_message_sent_at")
                message_ok["reward"] += 1
            except Exception as exc:
                failed.append(f"{name} · уведомление о начислении: {exc}")
                continue
            time.sleep(0.14)
        if not entry["thanks_sent"]:
            try:
                send_message(token, uid, thank_you(uid, entry.get("first_name"), entry.get("last_name"), entry.get("username")))
                mark_delivered(season_id, uid, "thanks_message_sent_at")
                message_ok["thanks"] += 1
            except Exception as exc:
                failed.append(f"{name} · благодарственное письмо: {exc}")
            time.sleep(0.14)
    print(f"Отправлено уведомлений: {message_ok['reward']}; писем: {message_ok['thanks']}")
    if failed:
        print(f"Не удалось отправить {len(failed)} сообщений (можно повторить --apply):")
        for error in failed:
            print("  -", error)
    else:
        print("ГОТОВО: все доступные личные сообщения отправлены.")
    print("Повторный запуск не начислит повторные +200 🐾 тем же пользователям.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RuntimeError, ValueError, OSError) as exc:
        print("ОШИБКА:", exc, file=sys.stderr)
        raise SystemExit(1)
